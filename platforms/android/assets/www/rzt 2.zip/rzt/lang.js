window.languages = {
		
	"ch": {
		"startGame": "",
		"selectLevel": "选择难度",
		"easy": "简单",
		"medium": "中等",
		"hard": "困难",
		"youNeed": "需要",
		"youNeed2": "分数",
		"points": "分数",
		"best": "最好成绩",
		"resume": "继续",
		"backToMenu": "回到菜单",
		"moreGames": "更多游戏"
	},
};