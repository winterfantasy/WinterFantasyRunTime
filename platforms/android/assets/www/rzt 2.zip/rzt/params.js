window.params = {
		"pointsForMedium": 1500,
		"pointsForHard": 3000
	};